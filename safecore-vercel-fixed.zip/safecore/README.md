# SafeCore — approval-gated action system

SafeCore is a safety-first foundation for an approval-gated action workflow. It includes the original state machine, audit logic, API, persistent-store adapter, and a new Vercel-friendly browser console.

## What was added
- `public/index.html` — responsive dashboard at `/` so the Vercel deployment no longer returns 404.
- System-health panel using `/api/health`.
- Authenticated action console using `/api/actions`.
- Create, approve, cancel, and execute controls that call the existing safety API.
- No fake provider, fake balances, or claim of real-money execution.

## Vercel
Deploy the repository root containing `api/`, `lib/`, `migrations/`, `public/`, and `vercel.json`. Vercel serves `public/index.html` at `/` and the existing API functions under `/api/*`.

Required environment variables for the authenticated API:
- `APP_API_TOKEN` — at least 32 random characters
- `APP_USER_ID` — stable application user identifier
- `DATABASE_URL` — Postgres connection string for persistent state

For a temporary non-persistent test only, `ALLOW_EPHEMERAL_STORE=1` can be used. Do not treat that mode as production persistence.

## Current provider status
The bundled provider is intentionally `UnsupportedProvider`. The UI therefore does not pretend that execution can move money. A real provider adapter and sandbox verification are still required before any real financial integration.

## Local tests
`npm test`
